$(document).ready(function() 
{
	self.scrollTo(0,0);
});
